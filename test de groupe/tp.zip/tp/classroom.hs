-- data Exre = Val Int
--             | Add Exre Exre
--             | Mult Exre Exre

-- val :: Int -> b
-- add :: b -> b -> b
-- mult :: b -> b -> b

-- fold_ :: (Int->b) -> (b->)

data Tree = Leaft Int | Node Tree Int Tree

-- ecrire un foldTree

